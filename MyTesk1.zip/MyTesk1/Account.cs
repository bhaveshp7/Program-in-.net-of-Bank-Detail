﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTesk1
{
    public interface Transaction
    {
        // Define methods deposit(double amount) and withdraw(double amount).

        void Deposit(double amount);
        void Withdraw(double amount);

    }
     public abstract class Account 
    {

        private string account_Number;
        private double balance;

        
        public Account(string accountNumber, double balance)
        {
            this.account_Number = accountNumber;
            this.balance = balance;
        }
        public string AccountNumber
        {
            get { return account_Number; }
            set { account_Number = value; }
        }

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        public abstract double Calculate_Interest();

    }
}
