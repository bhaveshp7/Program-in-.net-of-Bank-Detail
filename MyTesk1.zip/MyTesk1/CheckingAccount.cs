﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MyTesk1
{
    public class CheckingAccount : Account, Transaction
    {
        private double overdraftLimit;


        public CheckingAccount(string accountNumber, double balance, double overdraftLimit)
            : base(accountNumber, balance)
        {
            this.overdraftLimit = overdraftLimit;
        }

        public override double Calculate_Interest()
        {
            return 0;
        }

        public void Deposit(double amount)
        {
            Balance += amount;
            Console.WriteLine($"your Deposited amount :- " + amount);
            Console.WriteLine("Your new Updated Balance :- " + Balance);
        }

        public void Withdraw(double amount)
        {
            if (amount <= Balance + overdraftLimit)
            {
                Balance -= amount;
                Console.WriteLine("Your  Withdrew amount :- "+amount);
                Console.WriteLine("Your new Updated Balance :- " + Balance);
            }
            else
            {
                Console.WriteLine("Your amount is Exceeded overdraft limit can not Withdrew.");
            }
        }
    }
}
