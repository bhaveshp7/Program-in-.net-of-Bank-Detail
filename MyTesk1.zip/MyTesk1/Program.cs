﻿namespace MyTesk1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-----Bank Account Details----\n");
            SavingsAccount savingsAccount = new SavingsAccount("BOBUD101", 1200, 1.5);
            Console.WriteLine("----Savings Account Details----.");
            savingsAccount.Deposit(1500);
            savingsAccount.Withdraw(500);
            Console.WriteLine($"Interest Savings_Account: {savingsAccount.Calculate_Interest()}\n");

            
            CheckingAccount checkingAccount = new CheckingAccount("KOTUD123", 801.0, 100.0);
            Console.WriteLine("-----Checking Account Details----.");
            checkingAccount.Deposit(400);
            checkingAccount.Withdraw(700);
            checkingAccount.Withdraw(500);
            Console.WriteLine($"Interest  Checking_Account: {checkingAccount.Calculate_Interest()}");
        }
    }
}
