﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTesk1
{
   
    public class SavingsAccount : Account, Transaction
    {
        private double interestRate;

        public SavingsAccount(string accountNumber, double balance, double interestRate)
           : base(accountNumber, balance)
        {
            this.interestRate = interestRate;
        }

        public override double Calculate_Interest()
        {
            return Balance * interestRate;
        }

        public void Deposit(double amount)
        {
            Balance += amount;
            Console.WriteLine("Deposited amount :- "+amount);
            Console.WriteLine("Your new Updated Balance :- "+Balance);
        }

        public void Withdraw(double amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                Console.WriteLine(" Your Withdrew amount :-" + amount);
                Console.WriteLine(" Your new Updated Balance :- " + Balance);   
            }
            else
            {
                Console.WriteLine("Insufficient funds in your account.");
            }
        }
    }
}
